﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aginte_koadroa_2
{
    internal class Datua
    {
        public int gakoa { get; set; }
        public int balioa { get; set; }
    }
}
